//
//  DogBreedsController.swift
//  DogAPI
//
//  Created by David Boyd on 5/5/21.
//

import Foundation


class DogBreedsController {
    
    static func fetchDog(completion: @escaping (Result<[String], DogError>) -> Void) {
        
        //Step 1: Create URL
        let baseURL = URL(string: "https://dog.ceo/api/breeds/list/all")
        
        guard let finalURL = baseURL else {return completion(.failure(.invalidURL))}
        
        //Step 2: Data Task
        URLSession.shared.dataTask(with: finalURL) { (data, response, error) in
            
            //Step 3: handle error
            if let error = error {
                return completion(.failure(.thrownError(error)))
            }
            //Step 4: handle response
            if let response = response as? HTTPURLResponse{
                print("STATUS CODE: \(response.statusCode)")
            }
            //Step 5: check data
            guard let data = data else {return completion(.failure(.noData))}
            
            //Step 6: decode data
            do {
                let decoder = JSONDecoder()
                let topLevelObject = try decoder.decode(TopLevelObject.self, from: data)
                let breed = topLevelObject.message

                completion(.success(breed.terrier))
                
            } catch {
                completion(.failure(.unableToDecode))
                
            }
        }.resume()
    }
    
}//End of class
