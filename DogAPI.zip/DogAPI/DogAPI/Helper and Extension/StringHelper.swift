//
//  StringHelper.swift
//  DogAPI
//
//  Created by David Boyd on 5/5/21.
//

import Foundation

extension StringProtocol {
    var firstUppercased: String { prefix(1).uppercased() + dropFirst() }
    var firstCapitalized: String { prefix(1).capitalized + dropFirst() }
}
