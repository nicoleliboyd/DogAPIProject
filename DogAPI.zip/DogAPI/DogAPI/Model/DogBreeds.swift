//
//  DogBreeds.swift
//  DogAPI
//
//  Created by David Boyd on 5/5/21.
//

import Foundation

struct TopLevelObject: Codable {
    let message : Breed
}

struct Breed: Codable {
    let terrier: [String]
}
